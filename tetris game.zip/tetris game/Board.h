#ifndef BOARD_H
#define BOARD_H

#include <SFML/Graphics.hpp>
#include <vector>
#include "Tetromino.h"

/**
 * Board class manages the game grid
 * Handles collision detection, line clearing, and block placement
 */
class Board {
public:
    static const int WIDTH = 10;   // Grid width in blocks
    static const int HEIGHT = 20;  // Grid height in blocks

    Board();

    // Board management
    void clear();
    bool isValidPosition(const Tetromino& tetromino) const;
    void placeTetromino(const Tetromino& tetromino);
    int clearLines(); // Returns number of lines cleared
    bool isGameOver() const;
    
    // Locked rows management
    void lockBottomRow();
    int getLockedRowCount() const { return lockedRows; }
    bool isRowLocked(int y) const;

    // Getters
    sf::Color getCell(int x, int y) const;
    bool isCellOccupied(int x, int y) const;

    // Ghost piece calculation
    int calculateGhostY(const Tetromino& tetromino) const;

private:
    // Grid: 0 = empty, color value = occupied
    std::vector<std::vector<sf::Color>> grid;
    int lockedRows; // Number of rows locked from the bottom

    // Check if a line is full
    bool isLineFull(int y) const;

    // Remove a line and shift down
    void removeLine(int y);
};

#endif
