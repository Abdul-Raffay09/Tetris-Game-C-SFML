#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include "Board.h"
#include "Tetromino.h"
#include "Renderer.h"
#include "ScoreManager.h"
#include "Menu.h"

/**
 * Game class manages the overall game state and logic
 * Handles game loop, input, timing, and game states
 */
class Game {
public:
    enum GameState { MAIN_MENU, PLAYING, PAUSED, GAME_OVER };
    enum DifficultyLevel { BEGINNER, ADVANCED };

    Game();
    void run();

private:
    // SFML components
    sf::RenderWindow window;
    sf::Font font;
    sf::Clock clock;
    sf::Clock inputClock;

    // Game components
    Board board;
    Tetromino currentPiece;
    Tetromino nextPiece;
    Tetromino heldPiece;
    ScoreManager scoreManager;
    Renderer renderer;
    Menu menu;

    // Game state
    GameState state;
    DifficultyLevel difficulty;
    float dropTimer;
    float difficultyTimer; // Timer for difficulty progression (5 minutes)
    bool canHold; // Prevents holding multiple times per piece
    bool hardDropPressed; // Debounce for space key

    // Core game methods
    void handleInput();
    void update(float deltaTime);
    void render();

    // Game logic
    void spawnNewPiece();
    void lockPiece();
    void holdCurrentPiece();
    void hardDrop();
    bool movePieceIfValid(Tetromino& piece);

    // State management
    void startNewGame();
    void startNewGame(DifficultyLevel selectedDifficulty);
    void pauseGame();
    void resumeGame();
    void gameOver();
    
    // Difficulty progression
    static constexpr float DIFFICULTY_PROGRESSION_TIME = 300.0f; // 5 minutes in seconds
    void checkDifficultyProgression(float deltaTime);
    void lockBottomRow();

    // Input constants
    static constexpr float INPUT_DELAY = 0.1f; // Delay between inputs in seconds
};

#endif
