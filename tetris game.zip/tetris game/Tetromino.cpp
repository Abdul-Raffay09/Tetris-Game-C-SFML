#include "Tetromino.h"
#include <cstdlib>
#include <ctime>

/**
 * Constructor: Initializes tetromino with given type
 */
Tetromino::Tetromino(Type type) : type(type), rotation(0), position(3, 0) {
    initializeShapes();
    color = getColorForType(type);
}

/**
 * Initialize shape data for all tetromino types and rotations
 * Each shape is represented as a vector of block positions
 */
void Tetromino::initializeShapes() {
    shapes.clear();
    
    switch (type) {
        case I: // I-piece (straight line)
            shapes = {
                {{0,1}, {1,1}, {2,1}, {3,1}}, // Horizontal
                {{2,0}, {2,1}, {2,2}, {2,3}}, // Vertical
                {{0,2}, {1,2}, {2,2}, {3,2}}, // Horizontal
                {{1,0}, {1,1}, {1,2}, {1,3}}  // Vertical
            };
            break;
            
        case J: // J-piece
            shapes = {
                {{0,0}, {0,1}, {1,1}, {2,1}}, // Rotation 0
                {{1,0}, {2,0}, {1,1}, {1,2}}, // Rotation 90
                {{0,1}, {1,1}, {2,1}, {2,2}}, // Rotation 180
                {{1,0}, {1,1}, {0,2}, {1,2}}  // Rotation 270
            };
            break;
            
        case L: // L-piece
            shapes = {
                {{2,0}, {0,1}, {1,1}, {2,1}}, // Rotation 0
                {{1,0}, {1,1}, {1,2}, {2,2}}, // Rotation 90
                {{0,1}, {1,1}, {2,1}, {0,2}}, // Rotation 180
                {{0,0}, {1,0}, {1,1}, {1,2}}  // Rotation 270
            };
            break;
            
        case O: // O-piece (square) - doesn't rotate
            shapes = {
                {{1,0}, {2,0}, {1,1}, {2,1}},
                {{1,0}, {2,0}, {1,1}, {2,1}},
                {{1,0}, {2,0}, {1,1}, {2,1}},
                {{1,0}, {2,0}, {1,1}, {2,1}}
            };
            break;
            
        case S: // S-piece
            shapes = {
                {{1,0}, {2,0}, {0,1}, {1,1}}, // Rotation 0
                {{1,0}, {1,1}, {2,1}, {2,2}}, // Rotation 90
                {{1,1}, {2,1}, {0,2}, {1,2}}, // Rotation 180
                {{0,0}, {0,1}, {1,1}, {1,2}}  // Rotation 270
            };
            break;
            
        case Z: // Z-piece
            shapes = {
                {{0,0}, {1,0}, {1,1}, {2,1}}, // Rotation 0
                {{2,0}, {1,1}, {2,1}, {1,2}}, // Rotation 90
                {{0,1}, {1,1}, {1,2}, {2,2}}, // Rotation 180
                {{1,0}, {0,1}, {1,1}, {0,2}}  // Rotation 270
            };
            break;
            
        case T: // T-piece
            shapes = {
                {{1,0}, {0,1}, {1,1}, {2,1}}, // Rotation 0
                {{1,0}, {1,1}, {2,1}, {1,2}}, // Rotation 90
                {{0,1}, {1,1}, {2,1}, {1,2}}, // Rotation 180
                {{1,0}, {0,1}, {1,1}, {1,2}}  // Rotation 270
            };
            break;
            
        case NONE:
            break;
    }
}

/**
 * Get color for each tetromino type
 */
sf::Color Tetromino::getColorForType(Type type) const {
    switch (type) {
        case I: return sf::Color(0, 255, 255);     // Light blue
        case J: return sf::Color(0, 0, 255);       // Dark blue
        case L: return sf::Color(255, 165, 0);     // Orange
        case O: return sf::Color(255, 255, 0);     // Yellow
        case S: return sf::Color(0, 255, 0);       // Green
        case Z: return sf::Color(255, 0, 0);       // Red
        case T: return sf::Color(255, 0, 255);     // Magenta
        default: return sf::Color::Transparent;
    }
}

/**
 * Movement methods
 */
void Tetromino::moveLeft() {
    position.x--;
}

void Tetromino::moveRight() {
    position.x++;
}

void Tetromino::moveDown() {
    position.y++;
}

/**
 * Rotate the tetromino clockwise
 */
void Tetromino::rotate() {
    rotation = (rotation + 1) % 4;
}

/**
 * Rotate back (for wall kick failure)
 */
void Tetromino::rotateBack() {
    rotation = (rotation + 3) % 4; // Same as -1 mod 4
}

/**
 * Get absolute block positions on the board
 */
std::vector<sf::Vector2i> Tetromino::getBlockPositions() const {
    std::vector<sf::Vector2i> positions;
    
    if (type == NONE || shapes.empty()) {
        return positions;
    }
    
    for (const auto& offset : shapes[rotation]) {
        positions.push_back(sf::Vector2i(position.x + offset.x, position.y + offset.y));
    }
    
    return positions;
}

/**
 * Get random tetromino type based on level
 * Level 1: Only I, O, T, L (4 types)
 * Level 2+: All 7 types
 */
Tetromino::Type Tetromino::getRandomType(int level) {
    static bool seeded = false;
    if (!seeded) {
        srand(static_cast<unsigned>(time(nullptr)));
        seeded = true;
    }
    
    if (level == 1) {
        // Level 1: Only 4 basic blocks
        int random = rand() % 4;
        switch (random) {
            case 0: return I;
            case 1: return O;
            case 2: return T;
            case 3: return L;
        }
    }
    
    // Level 2+: All 7 types
    int random = rand() % 7;
    return static_cast<Type>(random);
}
