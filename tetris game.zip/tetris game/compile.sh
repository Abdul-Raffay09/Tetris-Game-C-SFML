#!/bin/bash
# Tetris Game - Linux/Mac Compilation Script

echo "============================================"
echo " Tetris Game - Compilation Script"
echo "============================================"
echo ""

# Check for SFML
if ! pkg-config --exists sfml-all; then
    echo "ERROR: SFML not found!"
    echo "Please install SFML:"
    echo "  Ubuntu/Debian: sudo apt-get install libsfml-dev"
    echo "  Fedora: sudo dnf install SFML-devel"
    echo "  Arch: sudo pacman -S sfml"
    echo "  macOS: brew install sfml"
    exit 1
fi

echo "SFML found"
echo ""

# Check for font file
if [ ! -f "arial.ttf" ]; then
    echo "WARNING: arial.ttf not found!"
    echo "Attempting to copy system font..."
    
    # Try to find a system font
    if [ -f "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf" ]; then
        cp /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf ./arial.ttf
        echo "Copied DejaVuSans.ttf as arial.ttf"
    elif [ -f "/System/Library/Fonts/Supplemental/Arial.ttf" ]; then
        cp /System/Library/Fonts/Supplemental/Arial.ttf ./arial.ttf
        echo "Copied Arial.ttf"
    else
        echo "Could not find a suitable font!"
        echo "Please provide a TrueType font file named arial.ttf"
    fi
    echo ""
fi

echo "Compiling source files..."
g++ -c main.cpp Game.cpp Board.cpp Tetromino.cpp Renderer.cpp Menu.cpp ScoreManager.cpp \
    $(pkg-config --cflags sfml-all) -std=c++17

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Compilation failed!"
    exit 1
fi

echo "Linking..."
g++ main.o Game.o Board.o Tetromino.o Renderer.o Menu.o ScoreManager.o -o Tetris \
    $(pkg-config --libs sfml-graphics sfml-window sfml-system)

if [ $? -ne 0 ]; then
    echo ""
    echo "ERROR: Linking failed!"
    exit 1
fi

echo ""
echo "Cleaning up object files..."
rm -f *.o

echo ""
echo "============================================"
echo " Compilation successful!"
echo "============================================"
echo ""
echo "You can now run: ./Tetris"
echo "Make sure arial.ttf is in the same directory!"
echo ""

# Make executable
chmod +x Tetris
