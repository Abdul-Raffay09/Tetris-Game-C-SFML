#include "Game.h"
#include <iostream>

/**
 * Constructor: Initialize game window and components
 */
Game::Game() 
    : window(sf::VideoMode({900u, 720u}), "Tetris Game", sf::Style::Titlebar | sf::Style::Close),
      renderer(window, font),
      menu(window, font),
      state(MAIN_MENU),
      difficulty(BEGINNER),
      dropTimer(0.0f),
      difficultyTimer(0.0f),
      canHold(true),
      hardDropPressed(false) {
    
    // Load font
    if (!font.openFromFile("arial.ttf")) {
        throw std::runtime_error("Failed to load arial.ttf. Make sure the font file is in the game directory and is a valid TrueType font.");
    }
    
    window.setFramerateLimit(60);
}

/**
 * Main game loop
 */
void Game::run() {
    while (window.isOpen()) {
        switch (state) {
            case MAIN_MENU: {
                Menu::MenuAction action = menu.showMainMenu();
                
                if (action == Menu::START_GAME) {
                    // Show difficulty selection
                    Menu::MenuAction difficultyAction = menu.showDifficultySelect();
                    if (difficultyAction == Menu::SELECT_BEGINNER) {
                        startNewGame(BEGINNER);
                    } else if (difficultyAction == Menu::SELECT_ADVANCED) {
                        startNewGame(ADVANCED);
                    }
                } else if (action == Menu::VIEW_SCORES) {
                    menu.showHighScores(scoreManager.getHighScores());
                } else if (action == Menu::VIEW_HELP) {
                    menu.showHelpScreen();
                } else if (action == Menu::EXIT) {
                    window.close();
                }
                break;
            }
            
            case PLAYING: {
                handleInput();
                
                float deltaTime = clock.restart().asSeconds();
                update(deltaTime);
                render();
                break;
            }
            
            case PAUSED: {
                Menu::MenuAction action = menu.showPauseMenu();
                
                if (action == Menu::RESUME) {
                    resumeGame();
                } else if (action == Menu::RESTART) {
                    // Restart with same difficulty
                    startNewGame(difficulty);
                } else if (action == Menu::VIEW_SCORES) {
                    menu.showHighScores(scoreManager.getHighScores());
                } else if (action == Menu::VIEW_HELP) {
                    menu.showHelpScreen();
                } else if (action == Menu::EXIT) {
                    state = MAIN_MENU;
                }
                break;
            }
            
            case GAME_OVER: {
                gameOver();
                break;
            }
        }
    }
}

/**
 * Handle player input
 */
void Game::handleInput() {
    while (auto event = window.pollEvent()) {
        if (event->is<sf::Event::Closed>()) {
            window.close();
        }
        
        if (const auto* keyPress = event->getIf<sf::Event::KeyPressed>()) {
            if (keyPress->code == sf::Keyboard::Key::P) {
                pauseGame();
            }
        }
    }
    
    // Continuous input with delay
    if (inputClock.getElapsedTime().asSeconds() >= INPUT_DELAY) {
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Left)) {
            Tetromino temp = currentPiece;
            temp.moveLeft();
            if (board.isValidPosition(temp)) {
                currentPiece = temp;
            }
            inputClock.restart();
        }
        
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Right)) {
            Tetromino temp = currentPiece;
            temp.moveRight();
            if (board.isValidPosition(temp)) {
                currentPiece = temp;
            }
            inputClock.restart();
        }
        
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Down)) {
            Tetromino temp = currentPiece;
            temp.moveDown();
            if (board.isValidPosition(temp)) {
                currentPiece = temp;
                dropTimer = 0; // Reset drop timer
            }
            inputClock.restart();
        }
        
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Up)) {
            Tetromino temp = currentPiece;
            temp.rotate();
            if (!board.isValidPosition(temp)) {
                temp.rotateBack();
            } else {
                currentPiece = temp;
            }
            inputClock.restart();
        }
        
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::C)) {
            holdCurrentPiece();
            inputClock.restart();
        }
    }
    
    // Hard drop (space) - separate handling to prevent holding
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Space)) {
        if (!hardDropPressed) {
            hardDrop();
            hardDropPressed = true;
        }
    } else {
        hardDropPressed = false;
    }
}

/**
 * Update game state
 */
void Game::update(float deltaTime) {
    dropTimer += deltaTime;
    
    // Check difficulty progression (5 minute timer)
    checkDifficultyProgression(deltaTime);
    
    // Auto-drop based on level speed and difficulty
    float dropSpeed = scoreManager.getDropSpeed();
    if (difficulty == ADVANCED) {
        dropSpeed *= 0.7f; // 30% faster for advanced mode
    }
    
    if (dropTimer >= dropSpeed) {
        Tetromino temp = currentPiece;
        temp.moveDown();
        
        if (board.isValidPosition(temp)) {
            currentPiece = temp;
        } else {
            lockPiece();
        }
        
        dropTimer = 0;
    }
}

/**
 * Check difficulty progression - lock bottom row every 5 minutes
 */
void Game::checkDifficultyProgression(float deltaTime) {
    difficultyTimer += deltaTime;
    
    if (difficultyTimer >= DIFFICULTY_PROGRESSION_TIME) {
        lockBottomRow();
        difficultyTimer = 0.0f; // Reset timer for next interval
    }
}

/**
 * Lock the bottom row of the board
 */
void Game::lockBottomRow() {
    board.lockBottomRow();
}

/**
 * Render game graphics
 */
void Game::render() {
    renderer.clear();
    renderer.drawBoard(board);
    
    // Draw ghost piece
    int ghostY = board.calculateGhostY(currentPiece);
    renderer.drawGhostPiece(currentPiece, ghostY);
    
    renderer.drawTetromino(currentPiece);
    renderer.drawUI(scoreManager, nextPiece, heldPiece, difficultyTimer, board.getLockedRowCount());
    renderer.display();
}

/**
 * Spawn a new tetromino
 */
void Game::spawnNewPiece() {
    currentPiece = nextPiece;
    currentPiece.setPosition(sf::Vector2i(3, 0));
    
    // Pass difficulty level to determine available blocks
    int level = (difficulty == BEGINNER) ? 1 : 2;
    nextPiece = Tetromino(Tetromino::getRandomType(level));
    nextPiece.setPosition(sf::Vector2i(0, 0));
    
    canHold = true;
    
    // Check if game over
    if (!board.isValidPosition(currentPiece)) {
        state = GAME_OVER;
    }
}

/**
 * Lock piece and handle line clearing
 */
void Game::lockPiece() {
    board.placeTetromino(currentPiece);
    
    int linesCleared = board.clearLines();
    if (linesCleared > 0) {
        scoreManager.addScore(linesCleared, scoreManager.getLevel());
    }
    
    spawnNewPiece();
}

/**
 * Hold current piece
 */
void Game::holdCurrentPiece() {
    if (!canHold) return;
    
    if (heldPiece.getType() == Tetromino::NONE) {
        heldPiece = currentPiece;
        heldPiece.setPosition(sf::Vector2i(0, 0));
        spawnNewPiece();
    } else {
        Tetromino temp = currentPiece;
        currentPiece = heldPiece;
        currentPiece.setPosition(sf::Vector2i(3, 0));
        heldPiece = temp;
        heldPiece.setPosition(sf::Vector2i(0, 0));
    }
    
    canHold = false;
}

/**
 * Hard drop (instant drop)
 */
void Game::hardDrop() {
    while (true) {
        Tetromino temp = currentPiece;
        temp.moveDown();
        
        if (board.isValidPosition(temp)) {
            currentPiece = temp;
        } else {
            break;
        }
    }
    
    lockPiece();
}

/**
 * Start new game
 */
void Game::startNewGame() {
    startNewGame(BEGINNER); // Default to beginner
}

/**
 * Start new game with specified difficulty
 */
void Game::startNewGame(DifficultyLevel selectedDifficulty) {
    board.clear();
    scoreManager.reset();
    difficulty = selectedDifficulty;
    difficultyTimer = 0.0f;
    
    // Pass difficulty level to determine available blocks
    int level = (difficulty == BEGINNER) ? 1 : 2;
    currentPiece = Tetromino(Tetromino::getRandomType(level));
    currentPiece.setPosition(sf::Vector2i(3, 0));
    
    nextPiece = Tetromino(Tetromino::getRandomType(level));
    nextPiece.setPosition(sf::Vector2i(0, 0));
    
    heldPiece = Tetromino(Tetromino::NONE);
    
    dropTimer = 0;
    canHold = true;
    hardDropPressed = false;
    
    state = PLAYING;
    clock.restart();
}

/**
 * Pause game
 */
void Game::pauseGame() {
    // Don't reset difficultyTimer - progression continues
    if (state == PLAYING) {
        state = PAUSED;
    }
}

/**
 * Resume game
 */
void Game::resumeGame() {
    state = PLAYING;
    clock.restart();
}

/**
 * Handle game over
 */
void Game::gameOver() {
    int finalScore = scoreManager.getScore();
    
    // Check if it's a high score
    auto highScores = scoreManager.getHighScores();
    bool isHighScore = highScores.size() < 10 || 
                       finalScore > highScores.back().second;
    
    // Show game over screen
    menu.showGameOver(finalScore, isHighScore);
    
    // Save high score if applicable
    if (isHighScore) {
        std::string playerName = menu.getPlayerName();
        scoreManager.saveHighScore(playerName);
        menu.showHighScores(scoreManager.getHighScores());
    }
    
    state = MAIN_MENU;
}
