# IMPORTANT: Font File Required!

## ⚠️ REQUIRED FILE NOT INCLUDED

The game requires a TrueType font file named `arial.ttf` to run.
This file is NOT included in the project due to licensing restrictions.

## How to Get the Font

### Option 1: Windows
Copy from your Windows Fonts directory:
```
copy C:\Windows\Fonts\arial.ttf "c:\Users\Rafay\Desktop\tetris game\arial.ttf"
```

### Option 2: Linux
```bash
cp /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf ./arial.ttf
```

### Option 3: macOS
```bash
cp /System/Library/Fonts/Supplemental/Arial.ttf ./arial.ttf
```

### Option 4: Download
Download any TrueType font (.ttf) from:
- https://www.1001freefonts.com/
- https://fonts.google.com/
- Any other font repository

Save it as `arial.ttf` in this directory.

### Option 5: Use Different Font
You can use ANY .ttf file. Just rename it to `arial.ttf`, or edit `Game.cpp` line 17:

```cpp
// Change this:
if (!font.loadFromFile("arial.ttf")) {

// To this (with your font name):
if (!font.loadFromFile("YourFont.ttf")) {
```

## Recommended Free Fonts
- DejaVu Sans
- Liberation Sans
- Roboto
- Open Sans
- Noto Sans

---

**The game WILL NOT RUN without a font file!**
Please add `arial.ttf` before compiling and running.
