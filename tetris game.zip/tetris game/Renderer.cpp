#include "Renderer.h"
#include <sstream>
#include <iomanip>

/**
 * Constructor
 */
Renderer::Renderer(sf::RenderWindow& window, sf::Font& font) 
    : window(window), font(font) {
}

/**
 * Clear the window
 */
void Renderer::clear() {
    window.clear(sf::Color(20, 20, 30)); // Dark background
}

/**
 * Display rendered content
 */
void Renderer::display() {
    window.display();
}

/**
 * Draw the game board
 */
void Renderer::drawBoard(const Board& board) {
    // Draw border
    drawBorder();
    
    // Draw grid cells
    for (int y = 0; y < Board::HEIGHT; y++) {
        for (int x = 0; x < Board::WIDTH; x++) {
            sf::Color cellColor = board.getCell(x, y);
            
            if (cellColor != sf::Color::Transparent) {
                // Check if this is a locked row and darken it
                if (board.isRowLocked(y)) {
                    // Make locked blocks darker/grayer
                    sf::Color lockedColor = cellColor;
                    lockedColor.r = lockedColor.r / 2;
                    lockedColor.g = lockedColor.g / 2;
                    lockedColor.b = lockedColor.b / 2;
                    drawBlock(x, y, lockedColor);
                } else {
                    drawBlock(x, y, cellColor);
                }
            } else {
                // Draw grid lines for empty cells
                sf::RectangleShape cell(sf::Vector2f(BLOCK_SIZE - 1, BLOCK_SIZE - 1));
                cell.setPosition(sf::Vector2f(
                    BOARD_OFFSET_X + x * BLOCK_SIZE,
                    BOARD_OFFSET_Y + y * BLOCK_SIZE
                ));
                // Locked empty rows have different background
                if (board.isRowLocked(y)) {
                    cell.setFillColor(sf::Color(50, 50, 60));
                    cell.setOutlineColor(sf::Color(70, 70, 80));
                } else {
                    cell.setFillColor(sf::Color(30, 30, 40));
                    cell.setOutlineColor(sf::Color(40, 40, 50));
                }
                cell.setOutlineThickness(1);
                window.draw(cell);
            }
        }
    }
    
    // Draw a red line above locked rows if any exist
    int lockedCount = board.getLockedRowCount();
    if (lockedCount > 0) {
        int lockedLineY = Board::HEIGHT - lockedCount;
        sf::RectangleShape lockedLine;
        lockedLine.setSize(sf::Vector2f(Board::WIDTH * BLOCK_SIZE, 3));
        lockedLine.setPosition(sf::Vector2f(
            BOARD_OFFSET_X,
            BOARD_OFFSET_Y + lockedLineY * BLOCK_SIZE - 2
        ));
        lockedLine.setFillColor(sf::Color::Red);
        window.draw(lockedLine);
    }
}

/**
 * Draw a tetromino piece
 */
void Renderer::drawTetromino(const Tetromino& tetromino) {
    auto blocks = tetromino.getBlockPositions();
    sf::Color color = tetromino.getColor();
    
    for (const auto& block : blocks) {
        if (block.y >= 0) { // Don't draw blocks above the board
            drawBlock(block.x, block.y, color);
        }
    }
}

/**
 * Draw ghost piece (shadow)
 */
void Renderer::drawGhostPiece(const Tetromino& tetromino, int ghostY) {
    auto blocks = tetromino.getBlockPositions();
    sf::Color color = tetromino.getColor();
    
    int yOffset = ghostY - tetromino.getPosition().y;
    
    for (const auto& block : blocks) {
        int ghostBlockY = block.y + yOffset;
        if (ghostBlockY >= 0) {
            drawBlock(block.x, ghostBlockY, color, true); // true = ghost mode
        }
    }
}

/**
 * Draw UI elements (score, level, next piece, held piece)
 */
void Renderer::drawUI(const ScoreManager& scoreManager, 
                      const Tetromino& nextPiece, 
                      const Tetromino& heldPiece,
                      float difficultyTimer,
                      int lockedRows) {
    float x = UI_OFFSET_X;
    float y = BOARD_OFFSET_Y;
    
    // === LEFT COLUMN: Game Info ===
    
    // Draw title
    drawText("TETRIS", x, y - 30, 28, sf::Color::White);
    
    // Draw score
    std::ostringstream scoreStr;
    scoreStr << scoreManager.getScore();
    drawText("SCORE", x, y + 20, 18, sf::Color::White);
    drawText(scoreStr.str(), x, y + 42, 24, sf::Color::Yellow);
    
    // Draw level
    std::ostringstream levelStr;
    levelStr << scoreManager.getLevel();
    drawText("LEVEL", x, y + 90, 18, sf::Color::White);
    drawText(levelStr.str(), x, y + 112, 24, sf::Color::Cyan);
    
    // Draw lines
    std::ostringstream linesStr;
    linesStr << scoreManager.getLinesCleared();
    drawText("LINES", x, y + 160, 18, sf::Color::White);
    drawText(linesStr.str(), x, y + 182, 24, sf::Color::Green);
    
    // Draw difficulty timer (time until next row locks)
    float timerY = y + 230;
    if (difficultyTimer > 0) {
        float timeRemaining = 300.0f - difficultyTimer; // 5 minutes = 300 seconds
        int minutes = static_cast<int>(timeRemaining) / 60;
        int seconds = static_cast<int>(timeRemaining) % 60;
        std::ostringstream timerStr;
        timerStr << std::setfill('0') << std::setw(2) << minutes << ":" 
                 << std::setfill('0') << std::setw(2) << seconds;
        drawText("NEXT LOCK", x, timerY, 16, sf::Color::White);
        drawText(timerStr.str(), x, timerY + 22, 20, sf::Color::Red);
        timerY += 70;
    }
    
    // Draw locked rows count
    if (lockedRows > 0) {
        std::ostringstream lockedStr;
        lockedStr << lockedRows;
        drawText("LOCKED", x, timerY, 16, sf::Color::White);
        drawText(lockedStr.str(), x, timerY + 22, 20, sf::Color::Red);
    }
    
    // Draw next piece
    drawPreviewPiece(nextPiece, x, y + 350, "NEXT");
    
    // Draw held piece
    drawPreviewPiece(heldPiece, x, y + 480, "HOLD");
    
    // === RIGHT COLUMN: Controls ===
    float controlsX = CONTROLS_OFFSET_X;
    float controlsY = BOARD_OFFSET_Y + 30;
    
    drawText("CONTROLS", controlsX, controlsY, 18, sf::Color::Cyan);
    controlsY += 35;
    
    // Draw control instructions with better spacing
    drawText("Move Left", controlsX, controlsY, 13, sf::Color::White);
    drawText("Left Arrow", controlsX, controlsY + 16, 11, sf::Color(180, 180, 180));
    controlsY += 50;
    
    drawText("Move Right", controlsX, controlsY, 13, sf::Color::White);
    drawText("Right Arrow", controlsX, controlsY + 16, 11, sf::Color(180, 180, 180));
    controlsY += 50;
    
    drawText("Soft Drop", controlsX, controlsY, 13, sf::Color::White);
    drawText("Down Arrow", controlsX, controlsY + 16, 11, sf::Color(180, 180, 180));
    controlsY += 50;
    
    drawText("Rotate", controlsX, controlsY, 13, sf::Color::White);
    drawText("Up Arrow", controlsX, controlsY + 16, 11, sf::Color(180, 180, 180));
    controlsY += 50;
    
    drawText("Hard Drop", controlsX, controlsY, 13, sf::Color::White);
    drawText("Space", controlsX, controlsY + 16, 11, sf::Color(180, 180, 180));
    controlsY += 50;
    
    drawText("Hold Piece", controlsX, controlsY, 13, sf::Color::White);
    drawText("C Key", controlsX, controlsY + 16, 11, sf::Color(180, 180, 180));
    controlsY += 50;
    
    drawText("Pause", controlsX, controlsY, 13, sf::Color::White);
    drawText("P Key", controlsX, controlsY + 16, 11, sf::Color(180, 180, 180));
}

/**
 * Draw a single block
 */
void Renderer::drawBlock(int x, int y, sf::Color color, bool isGhost) {
    sf::RectangleShape block(sf::Vector2f(BLOCK_SIZE - 2, BLOCK_SIZE - 2));
    block.setPosition(sf::Vector2f(
        BOARD_OFFSET_X + x * BLOCK_SIZE + 1,
        BOARD_OFFSET_Y + y * BLOCK_SIZE + 1
    ));
    
    if (isGhost) {
        // Ghost piece: semi-transparent outline
        color.a = 60;
        block.setFillColor(sf::Color::Transparent);
        block.setOutlineColor(color);
        block.setOutlineThickness(2);
    } else {
        // Normal block: filled with highlight
        block.setFillColor(color);
        
        // Add highlight effect
        sf::Color lighter = color;
        lighter.r = std::min(255, color.r + 40);
        lighter.g = std::min(255, color.g + 40);
        lighter.b = std::min(255, color.b + 40);
        block.setOutlineColor(lighter);
        block.setOutlineThickness(2);
    }
    
    window.draw(block);
}

/**
 * Draw preview piece (next or hold)
 */
void Renderer::drawPreviewPiece(const Tetromino& piece, float x, float y, const std::string& label) {
    // Draw label
    drawText(label, x, y, 20, sf::Color::White);
    
    // Draw box
    sf::RectangleShape box(sf::Vector2f(120, 100));
    box.setPosition(sf::Vector2f(x, y + 30));
    box.setFillColor(sf::Color(30, 30, 40));
    box.setOutlineColor(sf::Color(100, 100, 120));
    box.setOutlineThickness(2);
    window.draw(box);
    
    // Draw piece
    if (piece.getType() != Tetromino::NONE) {
        auto blocks = piece.getBlockPositions();
        sf::Color color = piece.getColor();
        
        // Calculate center offset for preview
        float offsetX = x + 30;
        float offsetY = y + 50;
        
        for (const auto& block : blocks) {
            sf::RectangleShape previewBlock(sf::Vector2f(20, 20));
            previewBlock.setPosition(sf::Vector2f(
                offsetX + block.x * 22,
                offsetY + block.y * 22
            ));
            previewBlock.setFillColor(color);
            window.draw(previewBlock);
        }
    }
}

/**
 * Draw text at position
 */
void Renderer::drawText(const std::string& text, float x, float y, int size, sf::Color color) {
    sf::Text sfText(font);
    sfText.setString(text);
    sfText.setCharacterSize(size);
    sfText.setFillColor(color);
    sfText.setPosition(sf::Vector2f(x, y));
    window.draw(sfText);
}

/**
 * Draw board border
 */
void Renderer::drawBorder() {
    sf::RectangleShape border;
    border.setSize(sf::Vector2f(Board::WIDTH * BLOCK_SIZE + 4, Board::HEIGHT * BLOCK_SIZE + 4));
    border.setPosition(sf::Vector2f(BOARD_OFFSET_X - 2, BOARD_OFFSET_Y - 2));
    border.setFillColor(sf::Color::Transparent);
    border.setOutlineColor(sf::Color::White);
    border.setOutlineThickness(3);
    window.draw(border);
}
