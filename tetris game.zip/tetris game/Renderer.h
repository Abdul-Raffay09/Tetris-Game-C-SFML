#ifndef RENDERER_H
#define RENDERER_H

#include <SFML/Graphics.hpp>
#include "Board.h"
#include "Tetromino.h"
#include "ScoreManager.h"

/**
 * Renderer handles all drawing operations
 * Game board, tetrominos, UI elements, and ghost piece
 */
class Renderer {
public:
    static const int BLOCK_SIZE = 30;  // Size of each block in pixels
    static const int BOARD_OFFSET_X = 50;
    static const int BOARD_OFFSET_Y = 50;
    static const int UI_OFFSET_X = BOARD_OFFSET_X + Board::WIDTH * BLOCK_SIZE + 40;
    static const int CONTROLS_OFFSET_X = UI_OFFSET_X + 180;  // Controls in separate column

    Renderer(sf::RenderWindow& window, sf::Font& font);

    // Main rendering methods
    void drawBoard(const Board& board);
    void drawTetromino(const Tetromino& tetromino);
    void drawGhostPiece(const Tetromino& tetromino, int ghostY);
    void drawUI(const ScoreManager& scoreManager, 
                const Tetromino& nextPiece, 
                const Tetromino& heldPiece,
                float difficultyTimer = 0.0f,
                int lockedRows = 0);
    
    void clear();
    void display();

private:
    sf::RenderWindow& window;
    sf::Font& font;

    // Helper methods
    void drawBlock(int x, int y, sf::Color color, bool isGhost = false);
    void drawPreviewPiece(const Tetromino& piece, float x, float y, const std::string& label);
    void drawText(const std::string& text, float x, float y, int size, sf::Color color);
    void drawBorder();
};

#endif
