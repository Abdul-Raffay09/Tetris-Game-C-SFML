#include "ScoreManager.h"
#include <fstream>
#include <algorithm>
#include <sstream>

const std::string ScoreManager::HIGH_SCORE_FILE = "highscores.txt";

/**
 * Constructor: Initialize score manager
 */
ScoreManager::ScoreManager() : score(0), level(1), totalLines(0), linesForNextLevel(10) {
}

/**
 * Add score based on lines cleared
 * Scoring system:
 * 1 line: 10 × level
 * 2 lines: 30 × level
 * 3 lines: 60 × level
 * 4 lines: 100 × level
 */
void ScoreManager::addScore(int linesCleared, int currentLevel) {
    if (linesCleared <= 0) return;
    
    int points = 0;
    switch (linesCleared) {
        case 1: points = 10 * currentLevel; break;
        case 2: points = 30 * currentLevel; break;
        case 3: points = 60 * currentLevel; break;
        case 4: points = 100 * currentLevel; break;
        default: points = 100 * currentLevel; break;
    }
    
    score += points;
    totalLines += linesCleared;
    
    updateLevel();
}

/**
 * Reset score manager for new game
 */
void ScoreManager::reset() {
    score = 0;
    level = 1;
    totalLines = 0;
    linesForNextLevel = 10;
}

/**
 * Update level based on lines cleared
 * Every 10 lines increases the level
 */
void ScoreManager::updateLevel() {
    while (totalLines >= linesForNextLevel) {
        level++;
        linesForNextLevel += 10;
    }
}

/**
 * Get drop speed based on current level
 * Higher levels = faster drops
 */
float ScoreManager::getDropSpeed() const {
    float baseSpeed = 1.0f; // 1 second per drop at level 1
    float speedDecrease = 0.05f; // Each level reduces time by 0.05s
    float minSpeed = 0.1f; // Minimum drop time
    
    float speed = baseSpeed - (level - 1) * speedDecrease;
    return std::max(speed, minSpeed);
}

/**
 * Save current score to high scores file
 */
void ScoreManager::saveHighScore(const std::string& playerName) {
    std::vector<std::pair<std::string, int>> scores;
    loadHighScores(scores);
    
    // Add new score
    scores.push_back({playerName, score});
    
    // Sort by score (descending)
    std::sort(scores.begin(), scores.end(), 
              [](const auto& a, const auto& b) { return a.second > b.second; });
    
    // Keep only top MAX_HIGH_SCORES
    if (scores.size() > MAX_HIGH_SCORES) {
        scores.resize(MAX_HIGH_SCORES);
    }
    
    saveHighScores(scores);
}

/**
 * Get high scores list
 */
std::vector<std::pair<std::string, int>> ScoreManager::getHighScores() const {
    std::vector<std::pair<std::string, int>> scores;
    loadHighScores(scores);
    return scores;
}

/**
 * Load high scores from file
 */
void ScoreManager::loadHighScores(std::vector<std::pair<std::string, int>>& scores) const {
    scores.clear();
    std::ifstream file(HIGH_SCORE_FILE);
    
    if (!file.is_open()) {
        return; // File doesn't exist yet
    }
    
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string name;
        int scoreValue;
        
        if (std::getline(iss, name, ',') && iss >> scoreValue) {
            scores.push_back({name, scoreValue});
        }
    }
    
    file.close();
}

/**
 * Save high scores to file
 */
void ScoreManager::saveHighScores(const std::vector<std::pair<std::string, int>>& scores) const {
    std::ofstream file(HIGH_SCORE_FILE);
    
    if (!file.is_open()) {
        return;
    }
    
    for (const auto& score : scores) {
        file << score.first << "," << score.second << "\n";
    }
    
    file.close();
}
