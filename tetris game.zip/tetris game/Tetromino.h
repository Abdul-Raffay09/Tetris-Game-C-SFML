#ifndef TETROMINO_H
#define TETROMINO_H

#include <SFML/Graphics.hpp>
#include <vector>

/**
 * Tetromino class represents a single tetromino piece
 * Handles shape, position, rotation, and color
 */
class Tetromino {
public:
    // Tetromino types
    enum Type { I, J, L, O, S, Z, T, NONE };

    // Constructor
    Tetromino(Type type = NONE);

    // Movement methods
    void moveLeft();
    void moveRight();
    void moveDown();
    void rotate();
    void rotateBack(); // For wall kick failure

    // Getters
    std::vector<sf::Vector2i> getBlockPositions() const;
    sf::Color getColor() const { return color; }
    Type getType() const { return type; }
    sf::Vector2i getPosition() const { return position; }

    // Setters
    void setPosition(sf::Vector2i pos) { position = pos; }

    // Static method to get random tetromino type
    static Type getRandomType(int level);

private:
    Type type;
    sf::Color color;
    sf::Vector2i position; // Top-left position of the tetromino
    int rotation; // 0, 1, 2, 3 (0, 90, 180, 270 degrees)
    
    // Shape data for each tetromino type and rotation
    std::vector<std::vector<sf::Vector2i>> shapes;

    // Initialize shape data
    void initializeShapes();
    
    // Get color based on type
    sf::Color getColorForType(Type type) const;
};

#endif
