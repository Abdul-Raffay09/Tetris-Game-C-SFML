/**
 * Tetris Game
 * 
 * A complete implementation of the classic Tetris game using SFML
 * 
 * Features:
 * - All 7 tetromino types with rotation
 * - Ghost piece (shadow showing landing position)
 * - Hold piece functionality
 * - Level progression system
 * - High score tracking
 * - Multiple menus (main, pause, help, scores)
 * - Smooth controls and gameplay
 * 
 * Controls:
 * - Arrow Keys: Move and rotate
 * - Space: Hard drop
 * - C: Hold piece
 * - P: Pause
 * 
 * Author: Tetris Game Project
 * Date: 2025
 */

#include "Game.h"
#include <iostream>

int main() {
    try {
        Game game;
        game.run();
    } catch (const std::exception& e) {
        std::cerr << "\n========================================\n";
        std::cerr << "ERROR: " << e.what() << std::endl;
        std::cerr << "========================================\n\n";
        std::cerr << "Press Enter to exit...";
        std::cin.get();
        return 1;
    }
    
    return 0;
}
