#include "Board.h"

/**
 * Constructor: Initialize empty board
 */
Board::Board() {
    lockedRows = 0;
    clear();
}

/**
 * Clear the board
 */
void Board::clear() {
    grid.clear();
    grid.resize(HEIGHT, std::vector<sf::Color>(WIDTH, sf::Color::Transparent));
    lockedRows = 0;
}

/**
 * Check if tetromino can be placed at its current position
 */
bool Board::isValidPosition(const Tetromino& tetromino) const {
    auto blocks = tetromino.getBlockPositions();
    
    for (const auto& block : blocks) {
        // Check boundaries
        if (block.x < 0 || block.x >= WIDTH || block.y >= HEIGHT) {
            return false;
        }
        
        // Allow pieces to start above the board
        if (block.y < 0) {
            continue;
        }
        
        // Check if trying to enter locked rows
        if (isRowLocked(block.y)) {
            return false;
        }
        
        // Check collision with existing blocks
        if (isCellOccupied(block.x, block.y)) {
            return false;
        }
    }
    
    return true;
}

/**
 * Place tetromino on the board permanently
 */
void Board::placeTetromino(const Tetromino& tetromino) {
    auto blocks = tetromino.getBlockPositions();
    sf::Color color = tetromino.getColor();
    
    for (const auto& block : blocks) {
        if (block.y >= 0 && block.y < HEIGHT && block.x >= 0 && block.x < WIDTH) {
            grid[block.y][block.x] = color;
        }
    }
}

/**
 * Clear completed lines and return count
 */
int Board::clearLines() {
    int linesCleared = 0;
    
    // Check each line from bottom to top, but skip locked rows
    for (int y = HEIGHT - lockedRows - 1; y >= 0; y--) {
        if (isLineFull(y)) {
            removeLine(y);
            linesCleared++;
            y++; // Recheck this line since everything moved down
        }
    }
    
    return linesCleared;
}

/**
 * Check if a line is completely filled
 */
bool Board::isLineFull(int y) const {
    for (int x = 0; x < WIDTH; x++) {
        if (grid[y][x] == sf::Color::Transparent) {
            return false;
        }
    }
    return true;
}

/**
 * Remove a line and shift everything above it down
 */
void Board::removeLine(int y) {
    // Move all lines above down by one (but not into locked rows area)
    for (int row = y; row > 0; row--) {
        grid[row] = grid[row - 1];
    }
    
    // Clear the top line
    grid[0] = std::vector<sf::Color>(WIDTH, sf::Color::Transparent);
}

/**
 * Lock the bottom-most unlocked row
 */
void Board::lockBottomRow() {
    if (lockedRows < HEIGHT - 5) { // Keep at least 5 rows playable
        lockedRows++;
        
        // Fill the newly locked row with a distinct color pattern if empty
        int lockedY = HEIGHT - lockedRows;
        for (int x = 0; x < WIDTH; x++) {
            if (grid[lockedY][x] == sf::Color::Transparent) {
                // Create a gray locked pattern
                grid[lockedY][x] = sf::Color(80, 80, 80);
            }
        }
    }
}

/**
 * Check if a row is locked
 */
bool Board::isRowLocked(int y) const {
    return y >= HEIGHT - lockedRows;
}

/**
 * Check if game is over (blocks at top of screen)
 */
bool Board::isGameOver() const {
    // Check top two rows
    for (int y = 0; y < 2; y++) {
        for (int x = 0; x < WIDTH; x++) {
            if (isCellOccupied(x, y)) {
                return true;
            }
        }
    }
    return false;
}

/**
 * Get cell color at position
 */
sf::Color Board::getCell(int x, int y) const {
    if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT) {
        return sf::Color::Transparent;
    }
    return grid[y][x];
}

/**
 * Check if cell is occupied
 */
bool Board::isCellOccupied(int x, int y) const {
    if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT) {
        return false;
    }
    return grid[y][x] != sf::Color::Transparent;
}

/**
 * Calculate where the ghost piece should be (Y position)
 */
int Board::calculateGhostY(const Tetromino& tetromino) const {
    Tetromino ghost = tetromino;
    
    // Move down until collision
    while (isValidPosition(ghost)) {
        ghost.moveDown();
    }
    
    // Move back up one position
    return ghost.getPosition().y - 1;
}
