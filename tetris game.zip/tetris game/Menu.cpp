#include "Menu.h"
#include <sstream>

/**
 * Constructor
 */
Menu::Menu(sf::RenderWindow& window, sf::Font& font) 
    : window(window), font(font), selectedOption(0) {
}

/**
 * Show main menu and return selected action
 */
Menu::MenuAction Menu::showMainMenu() {
    std::vector<std::string> options = {
        "Start New Game",
        "View High Scores",
        "Help",
        "Exit"
    };
    
    while (true) {
        drawMenu(options, "TETRIS - MAIN MENU");
        int choice = handleMenuInput(options.size());
        
        if (choice == -2) {
            continue; // Redraw menu
        }
        
        switch (choice) {
            case 0: return START_GAME;  // Will trigger difficulty selection
            case 1: return VIEW_SCORES;
            case 2: return VIEW_HELP;
            case 3: return EXIT;
            default: return NONE;
        }
    }
}

/**
 * Show difficulty selection menu
 */
Menu::MenuAction Menu::showDifficultySelect() {
    std::vector<std::string> options = {
        "BEGINNER - 4 Block Types, Normal Speed",
        "ADVANCED - All Blocks, Faster Speed"
    };
    
    while (true) {
        drawMenu(options, "SELECT DIFFICULTY");
        int choice = handleMenuInput(options.size());
        
        if (choice == -2) {
            continue; // Redraw menu
        }
        
        switch (choice) {
            case 0: return SELECT_BEGINNER;
            case 1: return SELECT_ADVANCED;
            default: return NONE;
        }
    }
}

/**
 * Show pause menu and return selected action
 */
Menu::MenuAction Menu::showPauseMenu() {
    std::vector<std::string> options = {
        "Resume",
        "Restart Game",
        "View High Scores",
        "Help",
        "Exit to Main Menu"
    };
    
    while (true) {
        drawMenu(options, "GAME PAUSED");
        int choice = handleMenuInput(options.size());
        
        if (choice == -2) {
            continue; // Redraw menu
        }
        
        switch (choice) {
            case 0: return RESUME;
            case 1: return RESTART;
            case 2: return VIEW_SCORES;
            case 3: return VIEW_HELP;
            case 4: return EXIT;
            default: return NONE;
        }
    }
}

/**
 * Show help screen with game instructions
 */
void Menu::showHelpScreen() {
    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
                return;
            }
            if (const auto* keyPress = event->getIf<sf::Event::KeyPressed>()) {
                if (keyPress->code == sf::Keyboard::Key::Escape || 
                    keyPress->code == sf::Keyboard::Key::Enter) {
                    return;
                }
            }
        }
        
        window.clear(sf::Color(20, 20, 30));
        
        drawCenteredText("TETRIS - HELP", 50, 40, sf::Color::Yellow);
        
        float y = 120;
        drawText("GAME RULES:", 100, y, 24, sf::Color::White);
        y += 40;
        drawText("- Arrange falling blocks to form complete lines", 120, y, 18, sf::Color(200, 200, 200));
        y += 30;
        drawText("- Complete lines disappear and award points", 120, y, 18, sf::Color(200, 200, 200));
        y += 30;
        drawText("- Game ends when blocks reach the top", 120, y, 18, sf::Color(200, 200, 200));
        y += 30;
        drawText("- Level increases every 10 lines cleared", 120, y, 18, sf::Color(200, 200, 200));
        y += 30;
        drawText("- Every 5 minutes, bottom row becomes locked!", 120, y, 18, sf::Color::Red);
        
        y += 50;
        drawText("DIFFICULTY MODES:", 100, y, 24, sf::Color::White);
        y += 40;
        drawText("BEGINNER: 4 block types (I, O, T, L), normal speed", 120, y, 18, sf::Color::Green);
        y += 30;
        drawText("ADVANCED: All 7 block types, 30% faster drops", 120, y, 18, sf::Color::Yellow);
        
        y += 60;
        drawText("CONTROLS:", 100, y, 24, sf::Color::White);
        y += 40;
        drawText("Left Arrow   - Move piece left", 120, y, 18, sf::Color::Cyan);
        y += 30;
        drawText("Right Arrow  - Move piece right", 120, y, 18, sf::Color::Cyan);
        y += 30;
        drawText("Down Arrow   - Soft drop (faster fall)", 120, y, 18, sf::Color::Cyan);
        y += 30;
        drawText("Up Arrow     - Rotate piece clockwise", 120, y, 18, sf::Color::Cyan);
        y += 30;
        drawText("Space        - Hard drop (instant fall)", 120, y, 18, sf::Color::Cyan);
        y += 30;
        drawText("C            - Hold current piece", 120, y, 18, sf::Color::Cyan);
        y += 30;
        drawText("P            - Pause game", 120, y, 18, sf::Color::Cyan);
        
        y += 60;
        drawText("SCORING:", 100, y, 24, sf::Color::White);
        y += 40;
        drawText("1 Line   - 10 points x level", 120, y, 18, sf::Color::Green);
        y += 30;
        drawText("2 Lines  - 30 points x level", 120, y, 18, sf::Color::Green);
        y += 30;
        drawText("3 Lines  - 60 points x level", 120, y, 18, sf::Color::Green);
        y += 30;
        drawText("4 Lines  - 100 points x level", 120, y, 18, sf::Color::Green);
        
        drawCenteredText("Press ENTER or ESC to return", 650, 20, sf::Color::Yellow);
        
        window.display();
    }
}

/**
 * Show high scores screen
 */
void Menu::showHighScores(const std::vector<std::pair<std::string, int>>& scores) {
    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
                return;
            }
            if (const auto* keyPress = event->getIf<sf::Event::KeyPressed>()) {
                if (keyPress->code == sf::Keyboard::Key::Escape || 
                    keyPress->code == sf::Keyboard::Key::Enter) {
                    return;
                }
            }
        }
        
        window.clear(sf::Color(20, 20, 30));
        
        drawCenteredText("HIGH SCORES", 80, 40, sf::Color::Yellow);
        
        float y = 180;
        
        if (scores.empty()) {
            drawCenteredText("No high scores yet!", y, 24, sf::Color::White);
        } else {
            for (size_t i = 0; i < scores.size(); i++) {
                std::ostringstream oss;
                oss << (i + 1) << ".  " << scores[i].first << " - " << scores[i].second;
                
                sf::Color color = (i < 3) ? sf::Color::Yellow : sf::Color::White;
                drawCenteredText(oss.str(), y, 24, color);
                y += 40;
            }
        }
        
        drawCenteredText("Press ENTER or ESC to return", 650, 20, sf::Color::Yellow);
        
        window.display();
    }
}

/**
 * Show game over screen
 */
void Menu::showGameOver(int score, bool isHighScore) {
    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
                return;
            }
            if (const auto* keyPress = event->getIf<sf::Event::KeyPressed>()) {
                if (keyPress->code == sf::Keyboard::Key::Enter) {
                    return;
                }
            }
        }
        
        window.clear(sf::Color(20, 20, 30));
        
        drawCenteredText("GAME OVER", 200, 50, sf::Color::Red);
        
        std::ostringstream scoreStr;
        scoreStr << "Final Score: " << score;
        drawCenteredText(scoreStr.str(), 300, 36, sf::Color::White);
        
        if (isHighScore) {
            drawCenteredText("NEW HIGH SCORE!", 370, 32, sf::Color::Yellow);
        }
        
        drawCenteredText("Press ENTER to continue", 500, 24, sf::Color::Cyan);
        
        window.display();
    }
}

/**
 * Get player name for high score entry
 */
std::string Menu::getPlayerName() {
    std::string name = "";
    bool done = false;
    
    while (window.isOpen() && !done) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
                return "Player";
            }
            
            if (const auto* textEvent = event->getIf<sf::Event::TextEntered>()) {
                if (textEvent->unicode == '\b' && !name.empty()) {
                    // Backspace
                    name.pop_back();
                } else if (textEvent->unicode == '\r') {
                    // Enter
                    done = true;
                } else if (textEvent->unicode < 128 && name.length() < 15) {
                    // Regular character
                    char c = static_cast<char>(textEvent->unicode);
                    if (isalnum(c) || c == ' ' || c == '_') {
                        name += c;
                    }
                }
            }
        }
        
        window.clear(sf::Color(20, 20, 30));
        
        drawCenteredText("NEW HIGH SCORE!", 200, 40, sf::Color::Yellow);
        drawCenteredText("Enter your name:", 280, 28, sf::Color::White);
        
        std::string display = name.empty() ? "_" : name;
        drawCenteredText(display, 350, 36, sf::Color::Cyan);
        
        drawCenteredText("Press ENTER when done", 450, 20, sf::Color(150, 150, 150));
        
        window.display();
    }
    
    return name.empty() ? "Player" : name;
}

/**
 * Draw menu with options
 */
void Menu::drawMenu(const std::vector<std::string>& options, const std::string& title) {
    window.clear(sf::Color(20, 20, 30));
    
    // Draw title
    drawCenteredText(title, 150, 40, sf::Color::Yellow);
    
    // Draw options
    float startY = 300;
    float spacing = 60;
    
    for (size_t i = 0; i < options.size(); i++) {
        sf::Color color = (i == selectedOption) ? sf::Color::Cyan : sf::Color::White;
        std::string prefix = (i == selectedOption) ? "> " : "  ";
        drawCenteredText(prefix + options[i], startY + i * spacing, 28, color);
    }
    
    drawCenteredText("Use UP/DOWN arrows and ENTER to select", 650, 18, sf::Color(150, 150, 150));
    
    window.display();
}

/**
 * Handle menu input and return selected option
 */
int Menu::handleMenuInput(int optionCount) {
    while (window.isOpen()) {
        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
                return -1;
            }
            
            if (const auto* keyPress = event->getIf<sf::Event::KeyPressed>()) {
                if (keyPress->code == sf::Keyboard::Key::Up) {
                    selectedOption = (selectedOption - 1 + optionCount) % optionCount;
                    return -2; // Signal to redraw
                } else if (keyPress->code == sf::Keyboard::Key::Down) {
                    selectedOption = (selectedOption + 1) % optionCount;
                    return -2; // Signal to redraw
                } else if (keyPress->code == sf::Keyboard::Key::Enter) {
                    return selectedOption;
                }
            }
        }
    }
    
    return -1;
}

/**
 * Draw text at position
 */
void Menu::drawText(const std::string& text, float x, float y, int size, sf::Color color) {
    sf::Text sfText(font);
    sfText.setString(text);
    sfText.setCharacterSize(size);
    sfText.setFillColor(color);
    sfText.setPosition(sf::Vector2f(x, y));
    window.draw(sfText);
}

/**
 * Draw centered text
 */
void Menu::drawCenteredText(const std::string& text, float y, int size, sf::Color color) {
    sf::Text sfText(font);
    sfText.setString(text);
    sfText.setCharacterSize(size);
    sfText.setFillColor(color);
    
    sf::FloatRect bounds = sfText.getLocalBounds();
    sfText.setPosition(sf::Vector2f((window.getSize().x - bounds.size.x) / 2, y));
    
    window.draw(sfText);
}
