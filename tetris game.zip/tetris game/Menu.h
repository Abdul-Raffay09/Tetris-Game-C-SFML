#ifndef MENU_H
#define MENU_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <string>

/**
 * Menu class handles all menu screens
 * Main menu, pause menu, help screen, and high scores
 */
class Menu {
public:
    enum MenuType { MAIN_MENU, PAUSE_MENU, HELP_SCREEN, HIGH_SCORES, GAME_OVER, DIFFICULTY_SELECT };
    enum MenuAction { NONE, START_GAME, RESUME, RESTART, VIEW_SCORES, VIEW_HELP, EXIT, SELECT_BEGINNER, SELECT_ADVANCED };

    Menu(sf::RenderWindow& window, sf::Font& font);

    // Display menus
    MenuAction showMainMenu();
    MenuAction showDifficultySelect();
    MenuAction showPauseMenu();
    void showHelpScreen();
    void showHighScores(const std::vector<std::pair<std::string, int>>& scores);
    void showGameOver(int score, bool isHighScore);

    // Get player name for high score entry
    std::string getPlayerName();

private:
    sf::RenderWindow& window;
    sf::Font& font;
    int selectedOption;

    // Helper methods
    void drawMenu(const std::vector<std::string>& options, const std::string& title);
    int handleMenuInput(int optionCount);
    void drawText(const std::string& text, float x, float y, int size, sf::Color color);
    void drawCenteredText(const std::string& text, float y, int size, sf::Color color);
};

#endif
