#ifndef SCOREMANAGER_H
#define SCOREMANAGER_H

#include <string>
#include <vector>
#include <utility>

/**
 * ScoreManager handles scoring, level progression, and high score persistence
 */
class ScoreManager {
public:
    ScoreManager();

    // Score management
    void addScore(int linesCleared, int level);
    void reset();

    // Getters
    int getScore() const { return score; }
    int getLevel() const { return level; }
    int getLinesCleared() const { return totalLines; }
    float getDropSpeed() const; // Returns fall speed in seconds

    // High scores
    void saveHighScore(const std::string& playerName);
    std::vector<std::pair<std::string, int>> getHighScores() const;

private:
    int score;
    int level;
    int totalLines;
    int linesForNextLevel;

    static const std::string HIGH_SCORE_FILE;
    static const int MAX_HIGH_SCORES = 10;

    // Update level based on lines cleared
    void updateLevel();

    // File operations
    void loadHighScores(std::vector<std::pair<std::string, int>>& scores) const;
    void saveHighScores(const std::vector<std::pair<std::string, int>>& scores) const;
};

#endif
